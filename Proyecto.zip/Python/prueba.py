#importación del módulo
from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

#crear sentencia sql
sql = 'SELECT * FROM usuario'

#utilizar el metodo execute
cur.execute(sql)

#mostrar resultado
registro = cur.fetchall()
print(registro)

#cerrar conexión
cur.close()
conn.close()