#importación del módulo
from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

sql = 'SELECT * FROM usuario'

cur.execute(sql)

registro = cur.fetchall()

for fila in registro:
    print(fila)

cur.close()
conn.close()