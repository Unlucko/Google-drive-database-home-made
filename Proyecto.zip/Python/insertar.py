#importación del módulo
from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

#crear sentencia sql
sql = 'insert INTO usuario (id, nombre, correo, clave_usuario, archivo_guardados, no_rol, no_permisos) VALUES(%s,%s,%s,%s,%s,%s,%s)'

#solicitud de datos al usuario
id = input('Ingrese el codigo: ')
nombre = input('Ingrese el nombre: ')
correo = input('Ingrese el correo: ')
clave_usuario = input('Ingrese la clave: ')
archivo_guardados = input('Ingrese los archivos guardados: ')
no_rol = input('Ingrese número de rol: ')
no_permisos = input('Ingrese el número de permisos: ')


# recolección de datos 
datos = (id,nombre,correo,clave_usuario,archivo_guardados,no_rol,no_permisos)

#hacer uso del metodo execute
cur.execute(sql,datos)

#guardar registro
conn.commit()



#cerrar conexión
cur.close()
conn.close()