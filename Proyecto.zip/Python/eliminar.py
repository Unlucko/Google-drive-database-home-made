from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

#crear sentencia
sql = 'DELETE FROM usuario WHERE id=%s'

codigo_usuario = input('Ingrese el id del registro a eliminar: ')

cur.execute(sql,codigo_usuario)

conn.commit()

registro_eliminado = cur.rowcount()

print('registros eliminados: {registro_eliminado}')

cur.close()
conn.close()