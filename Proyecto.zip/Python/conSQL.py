def IndUso():
    return """SELECT usuario.nombre, usuario.archivo_guardados
                FROM usuario"""
                
def pes():
    return """SELECT Datos_archivo.peso_archivo, Datos_archivo.tipo_archivo
                FROM Datos_archivo
                WHERE Datos_archivo.codigo_carpeta = 200"""